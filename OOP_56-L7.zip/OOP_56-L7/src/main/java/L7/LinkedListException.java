package L7;

public class LinkedListException extends RuntimeException {
    public LinkedListException(String message) {
        super(message);
    }
}