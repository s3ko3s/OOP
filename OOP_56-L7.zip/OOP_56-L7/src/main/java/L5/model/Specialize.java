package L5.model;

public enum Specialize {

    PILATES,
    YOGA,
    FITNESS,
    ;

}
