package L5.exception;

public class TrainingTypeException extends Exception {

    public TrainingTypeException(String message){
        super(message);
    }
}
