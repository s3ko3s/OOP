package L5.exception;

public class TrainingIsBusyException extends RuntimeException {

    public TrainingIsBusyException(String message){
        super(message);
    }
}
